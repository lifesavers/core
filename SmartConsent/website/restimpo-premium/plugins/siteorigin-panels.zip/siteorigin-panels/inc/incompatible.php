<?php

// These are plugins that we've tested and are not compatible with Page Builder.
// Please visit our forums if you have any questions http://siteorigin.com/thread/
return array(
	'media-file-manager-advanced/media-relocator.php' => array(
		'more' => 'http://siteorigin.com/thread/incompatibility-media-file-manager-advanced/',
	),
);